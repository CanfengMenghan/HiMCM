var funcs = [];

for(var t = 0; t < 12; t++) {
	var theta = Math.PI / 6 * t; //与X轴正半轴夹角
	for(var i = 0; i < 5; i++) {
		var l = i * 2 + 2;
		funcs.push(
			(function (th, len) {
				return function (t) {
					var theta = Math.PI / 180 * t + th;
					return [len * Math.cos(theta), 3, len * Math.sin(theta), "#0f0"];
				};
			})(theta, l)
		);
		funcs.push(
			(function (th, len) {
				return function (t) {
					var theta = Math.PI / 180 * t + th;
					return [len * Math.cos(theta), -3, len * Math.sin(theta), "#0f0"];
				};
			})(theta, l)
		);
	}
	for(var i = 0; i < 6; i++) {
		var l = i * 2 + 1;
		funcs.push(
			(function (th, len) {
				return function (t) {
					var theta = Math.PI / 180 * t + th;
					return [len * Math.cos(theta), 0, len * Math.sin(theta), "#00f"];
				};
			})(theta, l)
		);
	}
}

for(var n = 0; n < 36; n++) {
	CIRCLE:
	var theta = Math.PI / 18 * n;
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta), 3, 12 * Math.sin(theta), "#000"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta), -3, 12 * Math.sin(theta), "#000"];
			};
		})(theta)
	);

	if(n % 3 === 0) {
		LEFT:
		go(theta, 1)
		RIGHT:
		go(theta, -1);
	}
}

function go (theta, num) {
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) - 0.75, num, 12 * Math.sin(theta), "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) + 0.75, num, 12 * Math.sin(theta), "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) - 0.75, num > 0 ? num + 0.5 : num - 0.5, 12 * Math.sin(theta) - 1, "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) + 0.75, num > 0 ? num + 0.5 : num - 0.5, 12 * Math.sin(theta) - 1, "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) - 0.75, num, 12 * Math.sin(theta) - 2, "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta) + 0.75, num, 12 * Math.sin(theta) - 2, "#359335"];
			};
		})(theta)
	);
	funcs.push(
		(function (th) {
			return function (t) {
				var theta = Math.PI / 180 * t + th;
				return [12 * Math.cos(theta), num, 12 * Math.sin(theta) - 2, "#359335"];
			};
		})(theta)
	);
}

SHELF:
for(var u = 0; u < 6; u++) {
	funcs.push(
		(function (i) {
			return function (t) {
				return [-i - 1, 5, (-i - 1) * Math.sqrt(3), "#dfb375"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [i + 1, 5, (-i - 1) * Math.sqrt(3), "#dfb375"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [-i - 1, -5, (-i - 1) * Math.sqrt(3), "#dfb375"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [i + 1, -5, (-i - 1) * Math.sqrt(3), "#dfb375"];
			};
		})(u)
	);
}

SHELF_BASE:
for(var u = 0; u < 8; u++) {
	funcs.push(
		(function (i) {
			return function (t) {
				return [(i - 3.5) * 2, 5, -7 * Math.sqrt(3), "#eec00b"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [(i - 3.5) * 2, -5, -7 * Math.sqrt(3), "#eec00b"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [(i - 3.5) * 2, 5, -7 * Math.sqrt(3) - 3, "#eec00b"];
			};
		})(u)
	);
	funcs.push(
		(function (i) {
			return function (t) {
				return [(i - 3.5) * 2, -5, -7 * Math.sqrt(3) - 3, "#eec00b"];
			};
		})(u)
	);
}
funcs.push(function (t) {
	return [7, 5, -7 * Math.sqrt(3) - 1.5, "#eec00b"];
});
funcs.push(function (t) {
	return [-7, -5, -7 * Math.sqrt(3) - 1.5, "#eec00b"];
});

OTHER:
funcs.push(function (t) {
	return [0, 0, 0, "#000"];
});
funcs.push(function (t) {
	return [0, 3, 0, "#0f0"];
});
funcs.push(function (t) {
	return [0, -3, 0, "#0f0"];
});
funcs.push(function (t) {
	return [0, 5, 0, "#eec00b"];
});
funcs.push(function (t) {
	return [0, -5, 0, "#eec00b"];
});
