var ctx_xy = $("#xy").get(0).getContext('2d');
var ctx_xz = $("#xz").get(0).getContext('2d');
var ctx_yz = $("#yz").get(0).getContext('2d');

ctx_xy.clearRect(0, 0, 800, 600);
ctx_xz.clearRect(0, 0, 800, 600);
ctx_yz.clearRect(0, 0, 800, 600);

function draw (x, y, z, color) {
	x *= 10;
	y *= 10;
	z *= 10;
	//x = x | 0;
	//y = y | 0;
	//z = z | 0;
	ctx_xy.clearRect(x - 20, 447 - y, 3, 3);
	ctx_xy.fillStyle = color || "#000";
	ctx_xy.fillRect(x - 20, 447 - y, 3, 3);
	ctx_xz.clearRect(x - 20, 447 - z, 3, 3);
	ctx_xz.fillStyle = color || "#000";
	ctx_xz.fillRect(x - 20, 447 - z, 3, 3);
	ctx_yz.clearRect(y - 20, 447 - z, 3, 3);
	ctx_yz.fillStyle = color || "#000";
	ctx_yz.fillRect(y - 20, 447 - z, 3, 3);
}
