function round (x) {
	if(Math.abs(Math.round(x) - x) <= Number.EPSILON) {
		return Math.round(x);
	}
	return x;
}