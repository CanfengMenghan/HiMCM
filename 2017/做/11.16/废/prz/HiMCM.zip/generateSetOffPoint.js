"use strict";

let drone = [];

for(var i = 0; i < 20; i++) { // y
	drone[i] = [];
	for(var j = 0; j < 20; j++) { // x
		drone[i][j] = new Drone(i, j);
	}
}

function Drone (yn, xn) {
	if(yn % 2 === 0) { //奇数排
		this.pos = new Point(xn * 2, yn * Math.sqrt(3), 0, "#ff0000");
	} else { //偶数排
		this.pos = new Point(xn * 2 + 1, yn * Math.sqrt(3), 0, "#00ff00");
	}
}

function Point (x, y, z, color) {
	this["x"] = this["0"] = x;
	this["y"] = this["1"] = y;
	this["z"] = this["2"] = z;
	this.color = color || "#000000";
}

drone = [];