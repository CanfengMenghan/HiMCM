"use strict";

//Script By JieJiSS

//const isSimilar = (v1, v2, d = 1e-4) => Math.abs(v1 - v2) < d;

/*
function Drone(f) {
    \/**
     * @param f<Function>(time: Number) => Number[]
     * @return Drone<Drone>
     *\/
    if (f(0).length < 3) {
        throw new TypeError(
            "Invalid Function f: requires f<Function> => Number[]"
        );
    }
    this.fx = f;
    this.changeTime = function(t) {
        let position = f(t);
        this.x = position[0];
        this.y = position[1];
        this.z = position[2];
        return position;
    };
    this.x = f(0)[0];
    this.y = f(0)[1];
    this.z = f(0)[2];
    this.currentTime = 0.0;
    this.next = function(padtime = 1e-5) {
        this.currentTime += padtime;
        return this.getPosition(this.currentTime);
    };
    this.getPosition = function(t) {
        return this.fx(t);
    };
}
*/
/*
function check() {
    // Start flying
    for (let t = 0.0; t <= 120; t += 1) {
        let table = [];
        funcs.forEach((func, index) => {
            let [x, y, z] = func(t);
            //check
            for (let i = 0; i < table.length; i++) {
                let [tx, ty, tz] = table[i];
                if (isSimilar(tx, x) && isSimilar(ty, y) && isSimilar(tz, z)) {
                    throw new Error(
                        `Crashed at [${[x, y, z]}]: fx${i} & fx${index}, t=${t}`
                    );
                }
            }
            table.push([x, y, z]);
            //console.log(table);
        });
    }
}
*/

function round(num) {
    let integer, decimal;
    if(num >= 0) {
        integer = Math.floor(num);
        decimal = num - integer;
    } else {
        integer = Math.ceil(num);
        decimal = num - integer;
    }
    decimal = Math.round(decimal * 1e12) / 1e12;
    return integer + decimal;
}
